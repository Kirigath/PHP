-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Waktu pembuatan: 19 Sep 2020 pada 09.04
-- Versi server: 5.7.31
-- Versi PHP: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bengkl`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `konsumen`
--

DROP TABLE IF EXISTS `konsumen`;
CREATE TABLE IF NOT EXISTS `konsumen` (
  `id_konsumen` varchar(255) NOT NULL,
  `nama_konsumen` varchar(255) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `jenis_kelamin` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_konsumen`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `konsumen`
--

INSERT INTO `konsumen` (`id_konsumen`, `nama_konsumen`, `alamat`, `jenis_kelamin`) VALUES
('K-01', 'andi ', 'Banda Aceh Jln.Hasan No.4', 'Laki-laki'),
('K-02', 'rudi', 'Banda Aceh Jln.manggis No.6', 'Laki-laki'),
('K-03', 'anwar', 'Banda Aceh Jln.sakti No.01', 'Laki-laki'),
('K-04', 'raihan', 'Banda Aceh Jln.Rawa  No.43', 'Perempuan'),
('K-05', 'zaki', 'Banda Aceh Jln.sukiman No.09', 'Laki-laki'),
('K-06', 'miswar', 'Banda Aceh Jln.nagka No.8', 'Laki-laki'),
('K-07', 'Danti', 'Banda Aceh', 'Perempuan'),
('K-08', 'Jingan', 'Test', 'Laki-laki');

-- --------------------------------------------------------

--
-- Struktur dari tabel `service`
--

DROP TABLE IF EXISTS `service`;
CREATE TABLE IF NOT EXISTS `service` (
  `id_service` varchar(255) NOT NULL,
  `nama_konsumen` varchar(255) DEFAULT NULL,
  `jenis_service` varchar(225) DEFAULT NULL,
  `keluhan` varchar(255) DEFAULT NULL,
  `tindakan_service` varchar(255) DEFAULT NULL,
  `tanggal_service` date DEFAULT NULL,
  PRIMARY KEY (`id_service`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `service`
--

INSERT INTO `service` (`id_service`, `nama_konsumen`, `jenis_service`, `keluhan`, `tindakan_service`, `tanggal_service`) VALUES
('S-01', 'Munawir', 'fast Track', 'hilang kunci ', 'buat kunci baru', '2020-07-14'),
('S-02', 'andi', 'Light service', 'kulit jok yang sudah kusam', 'pasang kulit jok', '2020-07-13'),
('S-03', 'rudi', 'Light service', 'kampas rem sudah habis', 'ganti rem ', '2020-07-12'),
('S-04', 'anwar', 'Light service', 'Motor tidak mau menyala lagi', 'ganti baterai', '2020-07-13'),
('S-05', 'raihan', 'Light service', 'spion lamam pecah', 'pasang spion', '2020-07-14'),
('S-06', 'zaki', 'Light service', 'bensin tersumbat', 'service karbu', '2020-07-11'),
('S-07', 'Danti', 'Fast Track', 'ban Sudah lewat masa', 'Ganti Ban', '2020-09-12');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sparepart`
--

DROP TABLE IF EXISTS `sparepart`;
CREATE TABLE IF NOT EXISTS `sparepart` (
  `id_sparepart` varchar(255) NOT NULL,
  `nama_sparepart` varchar(255) DEFAULT NULL,
  `jumlah_sparepart` varchar(255) DEFAULT NULL,
  `harga` bigint(255) DEFAULT NULL,
  PRIMARY KEY (`id_sparepart`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `sparepart`
--

INSERT INTO `sparepart` (`id_sparepart`, `nama_sparepart`, `jumlah_sparepart`, `harga`) VALUES
('SE-01', 'Oli Medis', '5', 45000),
('SE-02', 'Kampas Remm', '5', 20000),
('SE-03', 'Carbu Cleaner', '7', 45000),
('SE-04', 'Baterai Motor', '5', 200000),
('SE-05', 'Ban Dalam ', '10', 45000),
('SE-6', 'Kampas Rem', '2', 20000),
('SE-07', 'Lampu Sen', '20', 15000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

DROP TABLE IF EXISTS `transaksi`;
CREATE TABLE IF NOT EXISTS `transaksi` (
  `id_transaksi` varchar(255) NOT NULL,
  `id_service` varchar(255) DEFAULT NULL,
  `nama_konsumen` varchar(255) DEFAULT NULL,
  `nama_sparepart` varchar(255) DEFAULT NULL,
  `tanggal_service` date DEFAULT NULL,
  `jumlah_sparepart` varchar(255) DEFAULT NULL,
  `total_bayar` bigint(255) DEFAULT NULL,
  PRIMARY KEY (`id_transaksi`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_service`, `nama_konsumen`, `nama_sparepart`, `tanggal_service`, `jumlah_sparepart`, `total_bayar`) VALUES
('T-01', 'S-01', 'Munawirrrr', 'kunci', '2020-07-14', '2', 80000),
('T-02', 'S-02', 'andi', 'Kulit jok motor', '2020-07-13', '1', 80000),
('T-03', 'S-03', 'rudi', 'Kampas rem', '2020-07-12', '1', 100000),
('T-04', 'S-05', 'raihan', 'Spion', '2020-09-11', '2', 70000);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

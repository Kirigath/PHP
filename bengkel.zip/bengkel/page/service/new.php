<?php
$sql    = "SELECT * FROM service";
$result = $conn->query($sql);
?>

<div class="panel panel-default">
    <div class="panel-heading">Penambahan Data Service</div>
    <div class="panel-body">
        <div class="row">
            <div class="col-md-6">
                <form action="index.php?page=service/create.php" method="POST">
                    <div class="form-group">
                            <label>Kode Service</label>
                            <input class="form-control" name="id_service" placeholder="S-"/>
                    </div>

                    <div class="form-group">
                        <label>Nama Konsumen</label>
                        <input class="form-control" name="nama_konsumen"/>
                    </div>
                     <div class="form-group">
                                <label for="jenis_service">Jenis Service</label>
                                <select class="form-control" name="jenis_service">
                                <option value="0">- Pilih -</option>
                                <option value="Fast Track">Fast Track</option>
                                <option value="Light Service">Light Service</option>
                                <option value="Claim Service">Claim Service</option>
                                <option value="Heavy Reapair">Heavy Reapair</option>
                     </select>
                    <div class="form-group">
                        <label>Keluhan</label>
                        <input class="form-control" name="keluhan"/>
                    </div>
                    <div class="form-group">
                        <label>Tindakan Service</label>
                        <input class="form-control" name="tindakan_service" />
                    </div>
                    <div class="form-group">
                                <label>Tanggal service</label>
                                <input class="form-control" type="date" name="tanggal_service" />
                    </div>   
                    <div>
                        <button class="btn btn-primary" type="submit">Create</button>
                        <input class="btn btn-danger" type="reset" value="Reset">
                        <a href="index.php?page=service/index.php" class="btn btn-info" role="button" aria-pressed="true">
                            <font color="white">Back
                        </a></font>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
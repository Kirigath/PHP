<?php
$id_service= $_GET['id_service'];
$sql  = "DELETE FROM service WHERE id_service='$id_service'";
$conn->query($sql);

if ($sql) {
    echo "<script>alert('Data Berhasil dihapus!')
    location.replace('index.php?page=service/index.php')</script>";
} else {
    echo "<script>alert('Data Gagal dihapus!')
    location.replace('index.php?page=service/index.php')</script>";
}

<?php

$id_service        = $_POST['id_service'];
$nama_konsumen     = $_POST['nama_konsumen'];
$jenis_service     = $_POST['jenis_service'];
$keluhan     	   = $_POST['keluhan'];
$tindakan_service  = $_POST['tindakan_service'];
$tanggal_service   = $_POST['tanggal_service'];

$sql = "INSERT INTO service (id_service, nama_konsumen, jenis_service, keluhan, tindakan_service, tanggal_service)VALUES
		('$id_service', '$nama_konsumen', '$jenis_service', '$keluhan', '$tindakan_service', '$tanggal_service');
        ";

$conn->query($sql);
if ($sql){
        echo "<script>alert('Berhasil Disimpan');window.location='index.php?page=service/index.php'</script>";
        }
?>
<!--Query nya disini-->
<?php
$sql    = "SELECT * FROM service";
$result = $conn->query($sql);

$id_service       = $_GET['id_service'];
$service          = "SELECT * FROM service WHERE id_service='$id_service'";
$result_service   = $conn->query($service);
$rows              = $result_service->fetch_array();
?>
<!--Query nya disini Stop-->
<div class="container">
      <div class="panel panel-default">
            <div class="panel-heading">
                Data service -- Update
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-6">
                        <form action="index.php?page=service/update.php" method="POST">
                            <div class="form-group">
                                <label>Kode Service</label>
                                <input type="text" readonly class="form-control" name="id_service" value="<?php echo $rows['id_service']; ?>">
                            </div>

                            <div class="form-group">
                                <label>Nama Konsumen</label>
                                <input type="text" class="form-control" name="nama_konsumen" value="<?php echo $rows['nama_konsumen']; ?>">
                            </div>

                             <div class="form-group">
                                <label>Jenis Service</label>
                                <input type="text" class="form-control" name="jenis_service" value="<?php echo $rows['jenis_service']; ?>">
                                
                            </div>

                            <div class="form-group">
                                <label>Keluhan</label>
                                <input type="text" class="form-control" name="keluhan" value="<?php echo $rows['keluhan']; ?>">
                            </div>
                            <div class="form-group">
                                <label>Tindakan Service</label>
                                <input type="text" class="form-control" name="tindakan_service" value="<?php echo $rows['tindakan_service']; ?>">
                            </div>
                            <div class="form-group">
                                <label>tanggal service</label>
                                <input type="date" class="form-control" name="tanggal_service" value="<?php echo $rows['tanggal_service']; ?>">
                            </div>

                             <div>
                                <button class="btn btn-primary" type="submit">Update</button>
                                <input class="btn btn-danger" type="reset" value="Reset">
                                <a href="index.php?page=service/index.php" class="btn btn-info" role="button" aria-pressed="true"><font color="white">Kembali</a></font>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
</div>
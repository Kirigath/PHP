<?php

$id_service             =$_POST['id_service'];
$nama_konsumen          =$_POST['nama_konsumen'];
$jenis_service          =$_POST['jenis_service'];
$keluhan          		=$_POST['keluhan'];
$tindakan_service       =$_POST['tindakan_service'];
$tanggal_service        =$_POST['tanggal_service'];

$sql = "UPDATE service SET
        nama_konsumen='$nama_konsumen', jenis_service='$jenis_service', keluhan='$keluhan', tindakan_service='$tindakan_service',  tanggal_service='$tanggal_service'
        WHERE id_service='$id_service'
        ";

$conn->query($sql);
if ($sql){
        echo "<script>alert('Berhasil di Update');window.location='index.php?page=service/index.php'</script>";
        }
?>
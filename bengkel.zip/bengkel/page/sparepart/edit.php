<!--Query nya disini-->
<?php
$sql    = "SELECT * FROM sparepart";
$result = $conn->query($sql);

$id_sparepart       = $_GET['id_sparepart'];
$sparepart          = "SELECT * FROM sparepart WHERE id_sparepart ='$id_sparepart'";
$result_sparepart   = $conn->query($sparepart);
$rows              = $result_sparepart->fetch_array();
?>
<!--Query nya disini Stop-->
<div class="container">
      <div class="panel panel-default">
            <div class="panel-heading">
                Data Sparepart -- Update
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-6">
                        <form action="index.php?page=sparepart/update.php" method="POST">
                            <div class="form-group">
                                <label>Kode Sparepart</label>
                                <input type="text" readonly class="form-control" name="id_sparepart" value="<?php echo $rows['id_sparepart']; ?>">
                            </div>

                            <div class="form-group">
                                <label>nama_sparepart</label>
                                <input type="text" class="form-control" name="nama_sparepart" value="<?php echo $rows['nama_sparepart']; ?>">
                            </div>

                             <div class="form-group">
                                <label>jumlah_sparepart</label>
                                <input type="text" class="form-control" name="jumlah_sparepart" value="<?php echo $rows['jumlah_sparepart']; ?>">
                            </div>
                            <div class="form-group">
                                <label>harga</label>
                                <input type="text" class="form-control" name="harga"  value="<?php echo $rows['harga']; ?>">
                            </div>
                             <div>
                                <button class="btn btn-primary" type="submit">Update</button>
                                <input class="btn btn-danger" type="reset" value="Reset">
                                <a href="index.php?page=sparepart/index.php" class="btn btn-info" role="button" aria-pressed="true"><font color="white">Kembali</a></font>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
</div>
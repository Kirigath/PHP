<div class="row">
    <?php
    $sql    = "SELECT  * from sparepart";
    $result = $conn->query($sql);
    ?>
    <div class="col-md-12">
        <!-- Advanced Tables -->
        <div class="panel panel-default">
            <div class="panel-heading">
                Data Sparepart
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode Sparepart</th>
                                <th>Nama Sparepart</th>
                                <th>Jumlah Sparepart</th>
                                <th>Harga</th>
                                <th>Aksi</th>
                            </tr>

                        </thead>
                        <tbody>

                            <?php $i = 1; ?>
                            <?php foreach ($result as $row) : ?>

                                <tr>
                                    <td><?= $i; ?></td>
                                    <td><?php echo $row['id_sparepart']; ?></td>
                                    <td><?php echo $row['nama_sparepart']; ?></td>
                                    <td><?php echo $row['jumlah_sparepart']; ?></td>
                                    <td><?php echo $row['harga']; ?></td>
                                    <td class="table-bordered">

                                            <a href="index.php?page=sparepart/edit.php&id_sparepart=<?php echo $row['id_sparepart']; ?>"><span class="glyphicon glyphicon-edit"></span></a></a> | 
                                            <a href="index.php?page=sparepart/delete.php&id_sparepart=<?php echo $row['id_sparepart']; ?>" class="delete"><span class="glyphicon glyphicon-trash"></span></a>
                                            
                                    </td>
                                </tr>
                                <?php $i++; ?>
                            <?php endforeach; ?>

                        </tbody>
                    </table>
                </div>
                <a href="index.php?page=sparepart/new.php" class="btn btn-primary" style="margin: 7px">Tambah data</a>
                <a href="#" target="blank" class="btn btn-default" style="margin: 7px"><i class="fa fa-print"></i> ExportToExel</a>
                <a href="#" target="blank" class="btn btn-default" style="margin: 7px"><i class="fa fa-print"></i> ExportToPDF</a>
            </div>
        </div>
    </div>
</div>
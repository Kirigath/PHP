<?php

$id_sparepart            = $_POST['id_sparepart'];
$nama_sparepart          = $_POST['nama_sparepart'];
$jumlah_sparepart          = $_POST['jumlah_sparepart'];
$harga          		= $_POST['harga'];

$sql = "UPDATE sparepart SET
        nama_sparepart='$nama_sparepart', jumlah_sparepart='$jumlah_sparepart', harga='$harga'
        WHERE id_sparepart  ='$id_sparepart'
        ";

$conn->query($sql);
if ($sql){
        echo "<script>alert('Berhasil di Update');window.location='index.php?page=sparepart/index.php'</script>";
        }
?>
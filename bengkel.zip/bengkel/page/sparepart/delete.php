<?php
$id_sparepart = $_GET['id_sparepart'];
$sql  = "DELETE FROM sparepart WHERE id_sparepart='$id_sparepart'";
$conn->query($sql);

if ($sql) {
    echo "<script>alert('Data Berhasil dihapus!')
    location.replace('index.php?page=sparepart/index.php')</script>";
} else {
    echo "<script>alert('Data Gagal dihapus!')
    location.replace('index.php?page=sparepart/index.php')</script>";
}

<?php
$sql    = "SELECT * FROM sparepart";
$result = $conn->query($sql);
?>

<div class="panel panel-default">
    <div class="panel-heading">Penambahan Data Sparepart</div>
    <div class="panel-body">
        <div class="row">
            <div class="col-md-6">
                    <form action="index.php?page=sparepart/create.php" method="POST">
                    <div class="form-group">
                            <label>Kode Sparepart</label>
                            <input class="form-control" name="id_sparepart" placeholder="SE-"/>
                    </div>
                    <div class="form-group">
                        <label>Nama Sparepart</label>
                        <input class="form-control" name="nama_sparepart"/>
                    </div>
                    <div class="form-group">
                        <label>Jumlah Sparepart</label>
                        <input class="form-control" name="jumlah_sparepart"/>
                    </div>
                    <div class="form-group">
                        <label>Harga</label>
                        <input class="form-control" name="harga"/>
                    </div>
                                     <div>
                        <button class="btn btn-primary" type="submit">Create</button>
                        <input class="btn btn-danger" type="reset" value="Reset">
                        <a href="index.php?page=sparepart/index.php" class="btn btn-info" role="button" aria-pressed="true">
                            <font color="white">Back
                        </a></font>
                    </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php

$id_sparepart       = $_POST['id_sparepart'];
$nama_sparepart     = $_POST['nama_sparepart'];
$jumlah_sparepart   = $_POST['jumlah_sparepart'];
$harga              = $_POST['harga'];

$sql = "INSERT INTO sparepart
        (id_sparepart, nama_sparepart, jumlah_sparepart, harga)
        VALUES
        ('$id_sparepart', '$nama_sparepart', '$jumlah_sparepart', '$harga')
        ";

$conn->query($sql);
if ($sql){
        echo "<script>alert('Berhasil Disimpan');window.location='index.php?page=sparepart/index.php'</script>";
        }
?>
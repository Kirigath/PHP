<?php
$id_transaksi = $_GET['id_transaksi'];
$sql  = "DELETE FROM transaksi WHERE id_transaksi='$id_transaksi'";
$conn->query($sql);

if ($sql){
    echo "<script>alert('Data Berhasil dihapus!')
    location.replace('index.php?page=transaksi/index.php')</script>";
}else{
    echo "<script>alert('Data Gagal dihapus!')
    location.replace('index.php?page=transaksi/index.php')</script>";
}
?>

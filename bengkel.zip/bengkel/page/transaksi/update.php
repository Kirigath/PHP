<?php

$id_transaksi           = $_POST['id_transaksi'];
$id_service          	= $_POST['id_service'];
$nama_konsumen        	= $_POST['nama_konsumen'];
$nama_sparepart         = $_POST['nama_sparepart'];
$tanggal_service        = $_POST['tanggal_service'];
$jumlah_sparepart       = $_POST['jumlah_sparepart'];
$total_bayar         	= $_POST['total_bayar'];

$sql = "UPDATE transaksi SET
		id_service='$id_service', nama_konsumen='$nama_konsumen', nama_sparepart='$nama_sparepart', tanggal_service='$tanggal_service', jumlah_sparepart='$jumlah_sparepart', total_bayar='$total_bayar'
		WHERE id_transaksi='$id_transaksi'
		";
$conn->query($sql);
if ($sql){
        echo "<script>alert('Berhasil di Update');window.location='index.php?page=transaksi/index.php'</script>";
        }
?>
<div class="row">
    <?php
    $sql    = "SELECT  * from transaksi";
    $result = $conn->query($sql);
    ?>
    <div class="col-md-12">
        <!-- Advanced Tables -->
        <div class="panel panel-default">
            <div class="panel-heading">
                Data Transaksi
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Id transaksi</th>
                                <th>Id service</th>
                                <th>Nama Konsumen</th>
                                <th>Nama Sparepart</th> 
                                <th>Tanggal transaksi</th>
                                <th>Jumlah Sparepart</th>
                                <th>Total Harga</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $i = 1; ?>
                            <?php foreach ($result as $row) : ?>

                                <tr>
                                    <td><?= $i; ?></td>
                                    <td><?php echo $row['id_transaksi']; ?></td>
                                    <td><?php echo $row['id_service']; ?></td>
                                    <td><?php echo $row['nama_konsumen']; ?></td>
                                    <td><?php echo $row['nama_sparepart']; ?></td>
                                    <td><?php echo $row['tanggal_service']; ?></td>
                                    <td><?php echo $row['jumlah_sparepart']; ?></td>
                                    <td><?php echo $row['total_bayar']; ?></td>
                                    <td class="table-bordered">

                                            <a href="index.php?page=transaksi/edit.php&id_transaksi=<?php echo $row['id_transaksi']; ?>"><span class="glyphicon glyphicon-edit"></span></a></a> | 
                                            <a href="index.php?page=transaksi/delete.php&id_transaksi=<?php echo $row['id_transaksi']; ?>" class="delete"><span class="glyphicon glyphicon-trash"></span></a>
                                            
                                    </td>
                                </tr>
                                <?php $i++; ?>
                            <?php endforeach; ?>

                        </tbody>
                    </table>
                </div>
                <a href="index.php?page=transaksi/new.php" class="btn btn-primary" style="margin: 7px">Tambah Transaksi</a>
                <a href="#" target="blank" class="btn btn-default" style="margin: 7px"><i class="fa fa-print"></i> ExportToExel</a>
                <a href="#" target="blank" class="btn btn-default" style="margin: 7px"><i class="fa fa-print"></i> ExportToPDF</a>
            </div>
        </div>
    </div>
</div>
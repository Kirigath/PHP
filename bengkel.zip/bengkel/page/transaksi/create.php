<?php

$id_transaksi           = $_POST['id_transaksi'];
$id_service             = $_POST['id_service'];
$nama_konsumen        	= $_POST['nama_konsumen'];
$nama_sparepart         = $_POST['nama_sparepart'];
$tanggal_service        = $_POST['tanggal_service'];
$jumlah_sparepart       = $_POST['jumlah_sparepart'];
$total_bayar         	= $_POST['total_bayar'];

$sql = "INSERT INTO `transaksi` 
			(`id_transaksi`, `id_service`, `nama_konsumen`, `nama_sparepart`, `tanggal_service`, `jumlah_sparepart`, `total_bayar`)
		VALUES 
			('$id_transaksi', '$id_service', '$nama_konsumen', '$nama_sparepart', '$tanggal_service', '$jumlah_sparepart', '$total_bayar')";

$conn->query($sql);
if ($sql){
        echo "<script>alert('Berhasil Disimpan');window.location='index.php?page=transaksi/index.php'</script>";
        }
?>
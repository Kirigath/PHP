<!--Query nya disini-->
<?php
$sql    = "SELECT * FROM transaksi";
$result = $conn->query($sql);

$id_transaksi       = $_GET['id_transaksi'];
$transaksi          = "SELECT * FROM transaksi WHERE id_transaksi='$id_transaksi'";
$result_transaksi   = $conn->query($transaksi);
$rows               = $result_transaksi->fetch_array();
?>
<!--Query nya disini Stop-->
<div class="container">
      <div class="panel panel-default">
            <div class="panel-heading">
                Data transaksi -- Update
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-6">
                        <form action="index.php?page=transaksi/update.php" method="POST">
                            <div class="form-group">
                                <label>Kode transaksi</label>
                                <input type="text" readonly class="form-control" name="id_transaksi" value="<?php echo $rows['id_transaksi']; ?>">
                            </div>

                            <div class="form-group">
                                <label>ID service</label>
                                <input type="text" class="form-control" name="id_service" value="<?php echo $rows['id_service']; ?>">
                            </div>

                             <div class="form-group">
                                <label>nama Konsumen</label>
                                <input type="text" class="form-control" name="nama_konsumen" value="<?php echo $rows['nama_konsumen']; ?>">
                            </div>

                            <div class="form-group">
                                <label>nama sparepart</label>
                                <input type="text" class="form-control" name="nama_sparepart" value="<?php echo $rows['nama_sparepart']; ?>">
                            </div>

                            <div class="form-group">
                                <label>tanggal service</label>
                                <input type="date" class="form-control" name="tanggal_service" value="<?php echo $rows['tanggal_service']; ?>">
                            </div>

                            <div class="form-group">
                                <label>jumlah sparepart</label>
                                <input type="text" class="form-control" name="jumlah_sparepart" value="<?php echo $rows['jumlah_sparepart']; ?>">
                            </div>

                            <div class="form-group">
                                <label>total bayar</label>
                                <input type="text" class="form-control" name="total_bayar" value="<?php echo $rows['total_bayar']; ?>">
                            </div>

                            <div>
                                <button class="btn btn-primary" type="submit">Update</button>
                                <input class="btn btn-danger" type="reset" value="Reset">
                                <a href="index.php?page=transaksi/index.php" class="btn btn-info" role="button" aria-pressed="true"><font color="white">Kembali</a></font>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
</div>
<!--Query nya disini-->
<?php
$sql    = "SELECT * FROM transaksi";
$result = $conn->query($sql);
 ?>
<!--Query nya disini Stop-->
    <div class="container">
    	<div class="panel panel-default">
            <div class="panel-heading">
                Data Transaksi
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-6">
                        <form action="index.php?page=transaksi/create.php" method="POST">
                            <div class="form-group">
                                <label>Kode Transaksi</label>
                                <input class="form-control" name="id_transaksi" placeholder="T-"/>
                            </div>

                            <div class="form-group">
                                <label>ID service</label>
                                <input class="form-control" name="id_service" placeholder="S-"/>
                            </div>

                            <div class="form-group">
                                <label>Nama Konsumen</label>
                                <input class="form-control" name="nama_konsumen"/>
                            </div>

                             <div class="form-group">
                                <label>Nama sparepart</label>
                                <input class="form-control" name="nama_sparepart"/>
                            </div>

                            <div class="form-group">
                                <label>Tanggal service</label>
                                <input class="form-control" type="date" name="tanggal_service" />
                            </div>

                            <div class="form-group">
                                <label>jumlah_sparepart</label>
                                <input class="form-control" name="jumlah_sparepart"/>
                            </div>

                            <div class="form-group">
                                <label>total_bayar</label>
                                <input class="form-control" name="total_bayar" />
                            </div>

                            <div>
                                <button class="btn btn-primary" type="submit">Create</button>
                                <input class="btn btn-danger" type="reset" value="Reset">
                                <a href="index.php?page=transaksi/index.php" class="btn btn-info" role="button" aria-pressed="true"><font color="white">Back</a></font>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
</div>
        


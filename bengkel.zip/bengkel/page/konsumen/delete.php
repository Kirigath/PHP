<?php
$id_konsumen = $_GET['id_konsumen'];
$sql  = "DELETE FROM konsumen WHERE id_konsumen='$id_konsumen'";
$conn->query($sql);

if ($sql) {
    echo "<script>alert('Data Berhasil dihapus!')
    location.replace('index.php?page=konsumen/index.php')</script>";
} else {
    echo "<script>alert('Data Gagal dihapus!')
    location.replace('index.php?page=konsumen/index.php')</script>";
}

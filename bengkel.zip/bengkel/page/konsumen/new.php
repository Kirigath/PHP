<?php
$sql    = "SELECT * FROM konsumen";
$result = $conn->query($sql);
?>

<div class="panel panel-default">
    <div class="panel-heading">Penambahan Data Konsumen</div>
    <div class="panel-body">
        <div class="row">
            <div class="col-md-6">
                <form action="index.php?page=konsumen/create.php" method="POST">
                    <div class="form-group">
                            <label>Kode Konsumen</label>
                            <input class="form-control" name="id_konsumen" placeholder="K-"/>
                    </div>

                    <div class="form-group">
                        <label>Nama Konsumen</label>
                        <input class="form-control" name="nama_konsumen"/>
                    </div>

                     <div class="form-group">
                        <label>Alamat</label>
                        <input class="form-control" name="alamat"/>
                    </div>

                   
                    <div class="form-group">
                                <label for="jenis_kelamin">Jenis Kelamin</label>
                                <select class="form-control" name="jenis_kelamin">
                                <option value="0">- Pilih -</option>
                                <option value="Laki-laki">Laki-laki</option>
                                <option value="Perempuan">Perempuan</option>
                     </select>
                 </div>

                   
                    <div>
                        <button class="btn btn-primary" type="submit">Create</button>
                        <input class="btn btn-danger" type="reset" value="Reset">
                        <a href="index.php?page=konsumen/index.php" class="btn btn-info" role="button" aria-pressed="true">
                            <font color="white">Back
                        </a></font>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!--Query nya disini-->
<?php
$sql    = "SELECT * FROM konsumen";
$result = $conn->query($sql);

$id_konsumen       = $_GET['id_konsumen'];
$konsumen          = "SELECT * FROM konsumen WHERE id_konsumen='$id_konsumen'";
$result_konsumen   = $conn->query($konsumen);
$rows              = $result_konsumen->fetch_array();
?>
<!--Query nya disini Stop-->
<div class="container">
      <div class="panel panel-default">
            <div class="panel-heading">
                Data Konsumen -- Update
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-6">
                        <form action="index.php?page=konsumen/update.php" method="POST">
                            <div class="form-group">
                                <label>Kode Konsumen</label>
                                <input type="text" readonly class="form-control" name="id_konsumen" value="<?php echo $rows['id_konsumen']; ?>">
                            </div>

                            <div class="form-group">
                                <label>Nama Konsumen</label>
                                <input type="text" class="form-control" name="nama_konsumen" value="<?php echo $rows['nama_konsumen']; ?>">
                            </div>

                             <div class="form-group">
                                <label>Alamat</label>
                                <input type="text" class="form-control" name="alamat" value="<?php echo $rows['alamat']; ?>">
                            </div>

                            <div class="form-group">
                                <label for="jenis_kelamin">Jenis Kelamin</label>
                                <select class="form-control" name="jenis_kelamin" value="<?php echo $rows['jenis_kelamin']; ?>">
                                    <option value="0">- Pilih -</option>
                                    <option value="Laki-laki">Laki-laki</option>
                                    <option value="Perempuan">Perempuan</option>
                                </select>
                            </div>

                             <div>
                                <button class="btn btn-primary" type="submit">Update</button>
                                <input class="btn btn-danger" type="reset" value="Reset">
                                <a href="index.php?page=konsumen/index.php" class="btn btn-info" role="button" aria-pressed="true"><font color="white">Kembali</a></font>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
</div>
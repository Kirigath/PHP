<?php

$id_konsumen            = $_POST['id_konsumen'];
$nama_konsumen          = $_POST['nama_konsumen'];
$jenis_kelamin          = $_POST['jenis_kelamin'];
$alamat          		= $_POST['alamat'];

$sql = "UPDATE konsumen SET
        nama_konsumen='$nama_konsumen', jenis_kelamin='$jenis_kelamin', alamat='$alamat'
        WHERE id_konsumen  ='$id_konsumen'
        ";

$conn->query($sql);
if ($sql){
        echo "<script>alert('Berhasil di Update');window.location='index.php?page=konsumen/index.php'</script>";
        }
?>
<?php

$id_konsumen       = $_POST['id_konsumen'];
$nama_konsumen     = $_POST['nama_konsumen'];
$alamat            = $_POST['alamat'];
$jenis_kelamin     = $_POST['jenis_kelamin'];

$sql = "INSERT INTO konsumen
        (id_konsumen, nama_konsumen, alamat, jenis_kelamin)
        VALUES
        ('$id_konsumen', '$nama_konsumen', '$alamat', '$jenis_kelamin')
        ";

$conn->query($sql);
if ($sql){
        echo "<script>alert('Berhasil Disimpan');window.location='index.php?page=konsumen/index.php'</script>";
        }
?>